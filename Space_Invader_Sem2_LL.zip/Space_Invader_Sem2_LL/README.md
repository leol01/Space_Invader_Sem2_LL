Spielregeln:
        1. Bewegen Sie das VfB - Wappen mit der Maus.
        2. Klicken Sie die linke Maustaste oder drücken Sie die Leertaste, um andere Vereine zu schlagen.
        3. Berühren Sie die Meisterschale, um eine Meisterschaft zu gewinnen.
           Die Anzahl der gewonnenen Meisterschaften wird rechts oben angezeigt, sowie durch die Sterne über dem Wappen.
        4. Berühren Sie einen Gegner, so haben sie das Spiel verloren.
        5. Können Sie den DFB- oder den CL- Pokal gewinnen, so erhalten sie ein Extraleben. -> Stuttgart international ;)
        6. Mit der Taste P könenn Sie das Spiel pausieren.
        7. Nach Spielende können Sie Ihren Namen eintragen und die Spielstandliste einsehen.